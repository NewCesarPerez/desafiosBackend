db.productos.insertMany(productos)
db.mensajes.insertMany(mensajes)
db.productos.find()
db.mensajes.find()
db.productos.estimatedDocumentCount()
db.mensajes.estimatedDocumentCount()
db.productos.insertOne(productToAdd)
db.productos.find(
    {$and:[
        {marca:'Samsung'},
        {precio:{$lt:100000}}
    ]
    }
)
db.productos.find(
    {$and:[
        {precio:{$gt:50000}},
        {precio:{$lt:300000}}
    ]
    }
)
db.productos.find(
    {$and:[
        {marca:'Samsung'},
        {precio:{$gt:1000000}}
    ]
    }
)
db.productos.find({},{nombre:1}).skip(2).limit(1).sort({precio:1})
db.productos.update({precio:{$gt:0}},{$set:{stock:100}},{multi: true})
db.productos.update({precio:{$gt:1000000}},{$set:{stock:0}},{multi: true})
db.productos.deleteMany({precio:{$lt:40000}})
db.createUser(
    {
        user:'pepe',
        pwd:"asd456",
        roles:[
            {role:"read", db:'ecommerce'}
        ]
    }
)


